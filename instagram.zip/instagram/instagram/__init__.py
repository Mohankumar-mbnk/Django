"""
instagram 
reels 
-------------------------------------------------------------------
instagram(directory)(project)
    instagram(package)
        settings.py  # contains all the settings --> INSTALLED_APPS, DATABASES, MIDDLEWARES
        urls.py # we will store the urls of a project and we import urls of applicatons
        asgi.py 
        wsgi.py
    manage.py # this is a main file 
    reels(application)
        apps.py
        admin.py
        urls.py # we will store the urls of an application
        views.py # we will implement business logic
        models.py # we will define the database schema
        tests.py





"""